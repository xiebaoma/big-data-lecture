一个热词分析系统

1，统计一段时间内的热词
2，对热词的情感打分

运行：
安装python java
python main.py